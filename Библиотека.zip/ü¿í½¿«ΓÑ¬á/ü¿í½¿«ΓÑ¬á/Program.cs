﻿//Фантров Алексей Бис-21

namespace Библиотека
{
    class Program
    {
        static void Main(string[] args)
        {
            library Library = new library();
            Library.Creature();
        }
    }
}
