﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Diagnostics;

namespace Библиотека
{
    class library // класс библиотеки
    {
        List<book> books = new List<book>(); // список с книгами
        public string lib = @"Библиотека"; // адрес библиотеки
        public string History = "History.txt"; // адрес файла с историей
        public void Creature()//метод создания библиотеки
        {
            books.Clear();
            DirectoryInfo dir = new DirectoryInfo(lib);
            foreach (var item in dir.GetFiles())
            {
                New_book(item.Name);
            }   
            Menu();
        }

        public void History_creature()//метод создания библиотеки
        {
            books.Clear();
            DirectoryInfo dir = new DirectoryInfo(lib);
            foreach (var item in dir.GetFiles())
            {
                New_book(item.Name);
            }
            History_menu();
        }

        public void New_book(string filename)// метод создания книги
        {
            string[] words = filename.Split('.');
            if (words.Length!=4)
            {
                return;
            }
            books.Add(new book(filename, words[0], words[1], words[2],words[3]));
        }

        protected book selected_book; //выбранная на данный момент книга
        protected int used_number;//её номер в векторе с книгами
        protected int history_used_number;//её номер в истории

        public void Сhange_name_and_year()//меняет название и год у книжки
        {
            Console.Clear();
            Console.WriteLine("Введите название книги");
            string name = Console.ReadLine();

            Console.WriteLine("Введите год книги");
            string year = Console.ReadLine();

            string new_name = selected_book.author + "." + name + "." + year + "." + selected_book.expansion;
            if (File.Exists(lib + "\\" + new_name))
            {
                Console.WriteLine("Такая книга уже существует!");
                Console.ReadKey();
            }
            else
            {
                File.Move(lib + "\\" + selected_book.filename, lib + "\\" + new_name);
                Console.WriteLine("Книга успешно переименована");
                Console.ReadKey();
            }
           
        }

        private bool In_file_exist(string filename) //проверка на существование строки в файле
        {
            string line;
            StreamReader file = new StreamReader(History);
            while ((line = file.ReadLine()) != null)
            {
                if (line == filename)
                {
                    file.Close();
                    return (true);
                }
            }
            file.Close();
            return (false);
        }

        public void Speshial_print()// метод вывода книг на экран
        {
            int number = 0;
            foreach (book el in books)
            {
                number++;
                if (number == used_number)
                {
                    Console.Write(">");
                    selected_book = el;
                }
                el.Print();
                Console.WriteLine();
            }
        }

        private int history_size;

        public void History_print()// метод вывода книг на экран
        {
            history_size = 0;
            int number = 0;
            foreach (book el in books)
            {
                if (In_file_exist(el.filename))
                {
                    number++;
                    if (number == history_used_number)
                    {
                        Console.Write(">");
                        selected_book = el;
                    }
                    history_size++;
                    el.Print();
                    Console.WriteLine();
                }              
            }
        }

        public void Add() // добавить файл из другой директории
        {
            Console.Clear();
            Console.WriteLine("Введите путь к книге");
            string way = Console.ReadLine();
            if (File.Exists(way))
            {
                uint point = 0;
                FileInfo fi = new FileInfo(way);
                foreach (char el in fi.Name)
                {
                    if (el =='.')
                    {
                        point++;
                    }
                }
                if (point == 0) 
                {
                    Console.WriteLine("Ошибка, Файл неизвестного формата!");
                    Console.ReadKey();
                    return;
                }

                if (point == 3)
                {
                    if (File.Exists(lib + "\\" + fi.Name))
                    {
                        Console.WriteLine("Такая книга уже есть в библиотеке!");
                        Console.ReadKey();
                    }
                    else
                    {
                        File.Move(way, lib + "\\" + fi.Name);
                        Console.WriteLine("Книга добавлена в библиотеку");
                        Console.ReadKey();
                    }
                    return;
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("Введите автора книги");
                    string author = Console.ReadLine();

                    Console.WriteLine("Введите название книги");
                    string name = Console.ReadLine();

                    Console.WriteLine("Введите год книги");
                    string year = Console.ReadLine();

                    string new_name = author + "." + name + "." + year + fi.Extension;
                    if (File.Exists(lib + "\\" + new_name))
                    {
                        Console.WriteLine("Такая книга уже есть в библиотеке!");
                        Console.ReadKey();
                    }
                    else
                    {
                        File.Move(way, lib + "\\" + new_name);
                        Console.WriteLine("Книга добавлена в библиотеку");
                        Console.ReadKey();
                    }
                    return;
                }

            }
            else
            {               
                Console.WriteLine("Ошибка, Введённая книга не существует!");
                Console.ReadKey();
            }
        }

        public void History_menu()// метод вывода истории на экран
        {
            if (books.Count == 0)
            {
                Console.Clear();
                Console.WriteLine("Библиотека пуста");
                Console.ReadKey();
            }
            else
            {
                history_used_number = 1;

                while (true)
                {
                    Console.Clear();
                    Console.WriteLine("Недавнооткрытые:");
                    Console.WriteLine("\nВыбирете книгу при помощи стрелок <вверх> <вниз>");
                    Console.WriteLine("Нажмите:\nEnter - чтобы окрыть книгу; Backspace - чтобы удалить книгу\nПробел - чтобы изменить у книги автора и год; Delete - чтобы очистить историю\nEscape - чтобы вернуться в главное меню\n");

                    History_print();

                    if (history_size == 0)
                    {
                        Console.Clear();
                        Console.WriteLine("История пуста");
                        Console.ReadKey();
                        return;
                    }

                    ConsoleKey key = Console.ReadKey().Key;
                    switch (key)
                    {
                        case ConsoleKey.DownArrow: // вниз
                            if (history_used_number != history_size)
                            {
                                history_used_number++;
                            }
                            else
                            {
                                history_used_number = 1;
                            }
                            break;
                        case ConsoleKey.UpArrow: // вверх
                            if (history_used_number != 1)
                            {
                                history_used_number--;
                            }
                            else
                            {
                                history_used_number = history_size;
                            }
                            break;
                        case ConsoleKey.Enter: // открыть программой по умолчанию
                            Process.Start(lib + "\\" + selected_book.filename);
                            break;
                        case ConsoleKey.Spacebar: // переименовать файл
                            Сhange_name_and_year();
                            File.AppendAllText(History, selected_book.filename + Environment.NewLine);
                            History_creature();
                            break;
                        case ConsoleKey.Backspace: // удалить файл
                            File.Delete(lib + "\\" + selected_book.filename);
                            History_creature();
                            break;
                        case ConsoleKey.Delete: // очистить историю
                            File.WriteAllText(History, string.Empty);
                            History_creature();
                            break;
                        case ConsoleKey.Escape: //назад в главное меню
                            Creature();
                            return;
                        default:
                            break;
                    }
                }
            }
        }

        public void Menu()// метод вывода книг на экран
        {
            if (books.Count == 0)
            {
                Console.Clear();
                Console.WriteLine("Библиотека пуста");
                Console.WriteLine("\nНажмите:\nA - чтобы добавить новую книгу\nF5 - чтобы обновить меню\nEscape - чтобы закрыть программу\n");

                ConsoleKey key = Console.ReadKey().Key;
                    switch (key)
                    {
                        case ConsoleKey.A: // добавить файл из другой директории
                            Add();
                            Creature();
                            return;
                        case ConsoleKey.F5: // обновление
                            Creature();
                            return;
                        case ConsoleKey.Escape: //esc - закрыть программу
                            System.Environment.Exit(0);
                            break;
                        default:
                            break;
                    }
                
            }
            else
            {
                used_number = 1;

                while (true)
                {
                    Console.Clear();
                    Console.WriteLine("Меню:");
                    Console.WriteLine("\nВыбирете книгу при помощи стрелок <вверх> <вниз>");
                    Console.WriteLine("Нажмите:\nEnter - чтобы окрыть книгу; Backspace - чтобы удалить книгу\nПробел, чтобы изменить у книги автора и год; A - чтобы добавить новую книгу\nF5 - чтобы обновить меню; tab - чтобы посмотреть недавно открытые\nEscape - чтобы закрыть программу\n");
                    Speshial_print();
                    ConsoleKey key = Console.ReadKey().Key;
                    switch (key)
                    {
                        case ConsoleKey.DownArrow: // вниз
                            if (used_number != books.Count)
                            {
                                used_number++;
                            }
                            else
                            {
                                used_number = 1;
                            }
                            break;
                        case ConsoleKey.UpArrow: // вверх
                            if (used_number != 1)
                            {
                                used_number--;
                            }
                            else
                            {
                                used_number = books.Count;
                            }
                            break;
                        case ConsoleKey.Enter: // открыть программой по умолчанию
                            Process.Start(lib+"\\"+selected_book.filename);
                            File.AppendAllText(History, selected_book.filename+ Environment.NewLine);
                            break;
                        case ConsoleKey.Spacebar: // переименовать файл
                            Сhange_name_and_year();
                            File.AppendAllText(History, selected_book.filename + Environment.NewLine);
                            Creature();
                            break;
                        case ConsoleKey.Backspace: // удалить файл
                            File.Delete(lib + "\\" + selected_book.filename);
                            Creature();
                            return;
                        case ConsoleKey.A: // добавить файл из другой директории
                            Add();
                            Creature();
                            return;
                        case ConsoleKey.F5: // обновление
                            Creature();
                            return;
                        case ConsoleKey.Tab: // история
                            History_menu();
                            Creature();
                            return;
                        case ConsoleKey.Escape: //esc - закрыть программу
                            System.Environment.Exit(0);
                            break;
                        default:
                            break;
                    }
                }
            }
        }
    }
}
