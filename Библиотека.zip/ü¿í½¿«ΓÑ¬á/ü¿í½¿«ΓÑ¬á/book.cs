﻿using System;


namespace Библиотека
{
    class book // класс книги
    {
        public string filename; //путь к файлу
        public string author; //первая часть имени файла
        public string name; //вторая часть имени файла
        public string year; //третья часть имени файла
        public string expansion; //расширение файла

        public book(string filename, string author, string name, string year, string expansion)
        {
            this.filename = filename;
            this.author = author;
            this.name = name;
            this.year = year;
            this.expansion = expansion;
        }

        public void Print()
        {
            Console.Write("Автор: " + author);
            Console.Write(" Название: " + name);
            Console.Write(" Год: " + year);
        }
    }
}
